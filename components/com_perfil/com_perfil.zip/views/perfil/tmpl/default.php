<?php
defined('_JEXEC') or die;
JHtml::_('behavior.formvalidator');
?>
<div class="wrapPerfil">
    <div id="componnetContent">
        <form  action="<?php echo JRoute::_('index.php?option=com_perfil&task=perfil.save'); ?>" method="post" name="perfilForm" id="perfilForm" class="form-validate form-horizontal well" enctype="multipart/form-data">
            <fieldset>
                <legend>
                    <?php echo JText::_('COM_PERFIL_REGISTRATION_PROFILE_LABEL'); ?>
                </legend>
                <?php
                foreach ($this->form->getFieldset('mainWrap') as $field):
                    if ($field->fieldname === 'ine' && ($field->value === 'Validada' || $field->value === 'Por_validar')) {
                        continue;
                    }
                    if ($field->fieldname === 'ine_status' && $field->value) {
                        echo "<div class='control-group alert-message'>
                            INE: $field->value
                        </div>";
                        continue;
                    }
                    ?>
                    <div class="control-group">
                        <div class="control-label">
                            <?php echo ($field->label); ?>
                        </div>
                        <div class="controls">
                            <?php if ($field->fieldname === 'password1') : ?>
                                <?php // Disables autocomplete       ?>
                                <input type="password" style="display:none">
                            <?php endif;
                            ?>
                            <?php
                            echo $field->input;
                            ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </fieldset>
            <div id="searchresults">

            </div>
            <div class="main-submit">
                <button type="submit" id="guardar" class="btn btn-primary validate">
                    <?php echo JText::_('JSUBMIT'); ?>
                </button>
            </div>
            <input type="hidden" name="option" value="com_perfil" />
            <input type="hidden" name="task" value="perfil.save" />
            <?php echo JHtml::_('form.token'); ?>
        </form>
        <div id="componnetContent">
        </div>
