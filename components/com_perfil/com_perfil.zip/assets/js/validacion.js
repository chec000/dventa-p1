
(function ($) {
    $(document).ready(function () {

        $("#jform_state").attr("data-show-subtext","true");
        $("#jform_state").attr("data-live-search","true");
        $('#jform_state').selectpicker();


        $("#jform_zip_code").attr("data-show-subtext","true");
        $("#jform_zip_code").attr("data-live-search","true");
        $('#jform_zip_code').selectpicker();
        $("#jform_zip_code").parent().append('<ul id="searchResult"></ul>');



        //$("#state").addClass("");


        $('#jform_TERM').parent().html($('#jform_TERM').parent().html()+Joomla.JText._("COM_USERS_TERM_COND"));
        
        var isCellphoneValid = function () {
            let cel = parseInt($('#jform_cellphone').val());
            if (isNaN(cel)) {
                $('#jform_cellphone_err').remove();
                $('#jform_cellphone-lbl, #jform_cellphone').addClass('invalid');
                $('<div id="jform_cellphone_err" class="invalid">El valor que ingresaste no es válido.</div>').insertAfter('#jform_cellphone');
                return false;
            }
            $('#jform_cellphone_err').remove();
            $('#jform_cellphone-lbl, #jform_cellphone').removeClass('invalid');
            return true;
        };
        var isEmailValid = function () {
            var isValid = true;
            var email = $('#jform_email').val();
            if (!email) {
                isValid = false;
            }
            if (!isValid) {
                $('#jform_email_err').remove();
                $('#jform_email-lbl, #jform_email').addClass('invalid');
                $('<div id="jform_email_err" class="invalid">El valor que ingresaste no es válido.</div>').insertAfter('#jform_email');
                return false;
            }
            $('#jform_email_err').remove();
            $('#jform_email-lbl, #jform_email').removeClass('invalid');
            return true;
        };
        $('#jform_cellphone').change(function () {
            return isCellphoneValid();
        });
        $('#jform_cellphone').keydown(function (event) {
            // Allow: backspace, delete, tab, escape, and enter
            // Allow: Ctrl+A
            // Allow: home, end, left, right
            // Allow 1-9
            // Allow 1-9 Numeric PAD
            // let it happen, don't do anything
            if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || event.keyCode == 13 || (event.keyCode == 65 && event.ctrlKey === true) || (event.keyCode >= 35 && event.keyCode <= 39) || (event.keyCode >= 48 && event.keyCode <= 57 && !event.shiftKey) || (event.keyCode >= 96 && event.keyCode <= 105)) {
                return;
            } else {
                // Ensure that it is a number and stop the keypress
                event.preventDefault();
            }
        });





        $('#jform_cellphone').change(function () {
            return isCellphoneValid();
        });
        $('#jform_cellphone').keydown(function (event) {
            // Allow: backspace, delete, tab, escape, and enter
            // Allow: Ctrl+A
            // Allow: home, end, left, right
            // Allow 1-9
            // Allow 1-9 Numeric PAD
            // let it happen, don't do anything
            if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || event.keyCode == 13 || (event.keyCode == 65 && event.ctrlKey === true) || (event.keyCode >= 35 && event.keyCode <= 39) || (event.keyCode >= 48 && event.keyCode <= 57 && !event.shiftKey) || (event.keyCode >= 96 && event.keyCode <= 105)) {
                return;
            } else {
                // Ensure that it is a number and stop the keypress
                event.preventDefault();
            }
        });

        $('#perfilForm').submit(function (event) {
            var response = true;

            if (!isEmailValid()) {
                response = false;
            }
            if (!isCellphoneValid()) {
                response = false;
            }
            if ($('.micheckbox').is(':checked')) {
                swal('Corregir los datos', 'Debe aceptar los términos y condiciones', "warning");
                return false;   
            }
            if (!response) {
                $(document).scrollTop();
                swal('Corregir los datos', 'Hay campos en el formulario que no se han capturado correctamente\nFavor de corregirlos', "warning");
                return false;
            }
        });

        $("#jform_zip_code").keyup(function(){
            var zip=$(this).val();
            if(zip.length>1){
                var key = $("#token").attr("name");
                var url='index.php?option=com_perfil&task=datosperfil.getDatos&format=raw';
                if(zip!=""||zip!=null){
                    $.ajax({
                        type:"POST",
                        url: url,
                        data:{zip:zip,token:key},
                    }).done(function(data) {

                        if(data!=""||data!=null){
                            var data = $.parseJSON(data);
                            $("#searchResult").empty();
                            $.each(data, function(i, item) {
                               var datos_zip= item.zip_code+" - "+item.location;
                                    $("#searchResult").append("<li data-zip='"+item.zip_code+"' data-location='"+item.location+"' data-town='"+item.town+"' data-city='"+item.city+"'  data-state='"+item.state+"'>"+datos_zip+" </li>");
                                });


                                $("#searchResult li").bind("click",function(){
                                    setText(this);
                                });

                        }

                    }).fail(function() {
                        console.log("error");
                    })
                    ;
                }
            }


        });



        function setText(element){
            $("#jform_zip_code").val(element.dataset.zip);
            $("#searchResult").empty();
            $("#jform_location").val(element.dataset.location);
            $("#jform_city").val(element.dataset.city);
            $("#jform_state").val(element.dataset.state);

        }
    });



}
)(jQuery);



