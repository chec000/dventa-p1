<?php

defined('_JEXEC') or die;

class PerfilControllerDatosperfil extends JControllerLegacy {

    public function getDatos()
    {

        $app = JFactory::getApplication();

        $task = $app->input->get('task', '');

        $token = $app->input->post->get('token', '');

        $zip = $app->input->post->get('zip', '');

        //var_dump($token,JSession::getFormToken());
        //die();
        if (md5($token) == md5(JSession::getFormToken())){

            }

        try{
            $db = JFactory::getDbo();
            $query = $db->getQuery(true);
            $zip='%'.$zip.'%';

            // Get the database object and a new query object.
            $query->select('z.*')
                ->from($db->quoteName('#__zip_codes','z'));
                //->where('z.zip_code like ' . $db->quote($zip));
            $query->where($db->quoteName('z.zip_code')." like ".$db->quote($zip). 'limit 10' );
            // Set and query the database.
            $db->setQuery($query);
            $response= $db->loadObjectList();

            echo json_encode($response);
            if($response){
                return  json_encode($response);
            }else{
                return null;
            }
        }catch (Exception $e){
            var_dump($e);
        }


    }

}
