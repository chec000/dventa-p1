DROP TABLE IF EXISTS `#__core_pmr_profiles`;
DROP TABLE IF EXISTS `#__core_pmr_users_blacklist`;
DROP TABLE IF EXISTS `#__core_user_info`;
