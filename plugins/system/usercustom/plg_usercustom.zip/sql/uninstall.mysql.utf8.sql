DROP TABLE IF EXISTS `#__core_pmr_profiles`;
